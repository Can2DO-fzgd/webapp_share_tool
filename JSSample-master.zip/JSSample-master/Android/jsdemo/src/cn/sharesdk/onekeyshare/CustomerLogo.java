/*
 * Offical Website:http://www.mob.com
 * Support QQ: 4006852216
 * Offical Wechat Account:ShareSDK   (We will inform you our updated news at the first time by Wechat, if we release a new version. If you get any problem, you can also contact us with Wechat, we will reply you within 24 hours.)
 *
 * Copyright (c) 2013 mob.com. All rights reserved.
 */

package cn.sharesdk.onekeyshare;

import android.graphics.Bitmap;
import android.view.View.OnClickListener;

/** custom gridview logo item */
public class CustomerLogo {
	public String label;
	public Bitmap logo;
	public OnClickListener listener;
}

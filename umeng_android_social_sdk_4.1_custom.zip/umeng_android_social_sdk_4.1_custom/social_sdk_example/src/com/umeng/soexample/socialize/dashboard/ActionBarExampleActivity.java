package com.umeng.soexample.socialize.dashboard;

import android.app.Activity;
import android.os.Bundle;

public class ActionBarExampleActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	}

	@Override
	protected void onResume() {
		super.onResume();

	}

}

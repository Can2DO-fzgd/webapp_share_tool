
package com.umeng.soexample.yxapi;

import com.umeng.socialize.yixin.controller.activity.YXCallbackActivity;


public class YXEntryActivity extends YXCallbackActivity {

}
